import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

public class QRcode {
	public static void main(String[] args) throws Exception 
	{
        String details = "fiche-produit";
    
        ByteArrayOutputStream out = QRCode.from(details).to(ImageType.JPG).stream();
        
        File f = new File("C:\\Users\\Moustapha\\Desktop\\COURS B3\\JAVA\\Projet\\QRcode\\t�l�chargement.jpg");
        FileOutputStream fos = new FileOutputStream(f);
        
        fos.write(out.toByteArray());
        fos.flush();
}
	
}
